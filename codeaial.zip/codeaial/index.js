//require express
const express = require('express');
//require a cookie parser
const cookieParser = require('cookie-parser');
// have all express related functionalities in app
const app = express();
//port number
const port = 8002;
//require a layputs
const expressLayouts = require('express-ejs-layouts');
//make app use the layout
const db = require('./config/mongoose');
//require express session to set the session
const session = require('express-session');
//require the passport
const passport = require('passport');
//require the passport local statergy
const passportLocal = require('./config/passport-local-statergy');
//for static files access
app.use(express.static('./assets'));
//let app use the expressLayouts
app.use(expressLayouts);
//used custom flash middle ware to pass with every responce
const customMware = require('./config/middleware');
//acting as a middleware
const sassMiddleWare = require('node-sass-middleware');
app.use(sassMiddleWare({
    src:'./assets/sass',
    dest:'./assets/css',
    debug:true,
    outputStyle:'extened',
    prefix:'/css'
}));
app.use(express.urlencoded());
//let app use the cookieParser
app.use(cookieParser());
//use of mongo store
const Mongostore = require('connect-mongo')(session);
//use connect-flash to show the message
const flash = require('connect-flash');


//extract styles from subpages
app.set('layout extractStyles',true);
app.set('layout extractScripts',true);

//setting up the view engine as ejs
app.set('view engine','ejs');
//setting up the views section
app.set('views','./views');
//mongo store store the cookie in the db

app.use(session({
    name:'codiaial',
    //TODo change when goes to production
    secret:'somethingsomething',
    saveUninitialized:false,
    resave:false,
    cookie:{
        maxAge:(1000 * 60 * 100)
    },
    store:new Mongostore({
            mongooseConnection:db,
            autoRemove:false
     },function(err){
         console.log(`Error in connect mongo db ${err}`);
         return;
     })
}));

app.use(passport.initialize());
app.use(passport.session());
app.use(passport.setAutheticatedUser);
//let app use the flash component
app.use(flash());
app.use(customMware.setFlash);
//use express router as a middleware
app.use('/',require('./routes'));
// make app listen to the specified port
app.listen(port,function(err){
   if(err){
       console.log(`Error : ${err}`);
       return;
   }
   console.log(`Express is running on port: ${port}`);
});