const User = require('../models/user');
module.exports.profile = function(req,res){
    User.findById(req.params.id,function(err,user) {
        if(err) {
            console.log(`Error in fetching the user ${err}`);
            return;
        }
        res.render('user-profile',{title:'user-profile',profile_user:user});
    });
   
}
//update function to get the profile updated implimented for name and email
module.exports.update = function(req,res){
    if(req.user.id == req.params.id) {
        User.findByIdAndUpdate(req.params.id,req.body,function(err,user) {
            res.end('<h1>User profile Updated Successfully</h1>');
        });
    }else{
        return res.status(401).send('Unauhorized');
    }
   
}

