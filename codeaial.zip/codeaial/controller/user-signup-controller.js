const User = require('../models/user');
module.exports.signup = function(req,res){
    if(req.body.password != req.body.conformpassword){
        return res.redirect('back');
    }
    User.findOne({email:req.body.email},function(err,user){
        if(err){
            console.log(`Error in creating the sign up ${err}`);
            return;
        }
        if(!user){
            User.create(req.body,function(err,user){
                if(err){
                    console.log(`Error in creating the sign up ${err}`);
                    return;
                }
                return res.redirect('/sign-in');
            });
        }else{
            return res.redirect('back');
        }

    });
    // return res.end('SignUp Successful',{title:'codiaial | Signup'});
}
module.exports.signin = function(req,res){
    // if(req.isAuthenticated){
    //     res.redirect('/users/profile'); 
    // }
    return res.render('signin',{title:'codiaial | Signin'});
}
module.exports.login = function(req,res){
    
    if(req.isAuthenticated){
        req.flash('success','Logged in successfully');
        return res.redirect('/');
    }
//    return res.redirect('/');
    //return res.end('Login Successfully',{title:'codiaial | login'});
}

module.exports.signout = function(req,res){
    req.logout();
    req.flash('success','Logged out  successfully');
    console.log("I was here xD")
    return res.redirect('/');
}


