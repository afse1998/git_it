const Post = require('../models/post');
const User = require('../models/user');
//using async and await function here
module.exports.home = async function(req,res){
    if(req.user){
        try{
            let posts =  await Post.find({}).populate('user')
            .populate({
                path:'comment',
                populate:{
                    path:'user'
                }
            });
           
           let users =   await User.find({});
                    return res.render('home',{
                        title:'codiaial | home',
                        posts:posts,
                        all_users:users
                     });
        }
        catch(err){
            console.log(`Error ${err}`);
            return;
        }
     }
    else{
        return res.redirect('/sign-in');
    }
}
