
const postCreationDateTime = require('node-datetime');
const Post = require('../models/post');
const Comment = require('../models/comment');
// var userPostsArray = [];

module.exports.create = async function(req,res){
    try{
        await Post.create({
            content:req.body.content,
            user:req.user._id 
         });   
         return res.redirect('back');
    }catch(err) {
        console.log(`Error ${err}`);
        return;
    }
};

module.exports.destroy = async function(req,res) {
    try {
        let posts = await Post.findById(req.params.id);
            //.idis used to convert the object id into String to compare with 
            if(posts.user == req.user.id) {
                //delete the posts of the particular user
                posts.remove();
                //to delete the comments by passing a query
               await  Comment.deleteMany({post : req.params.id});
               return res.redirect('back');
            }
            else {
                return res.redirect('back');
            }
    }catch(err) {
        console.log(`Error is ${err}`);
        return;
    }
    
}

