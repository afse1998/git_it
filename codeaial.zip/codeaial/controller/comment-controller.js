const Comment = require('../models/comment');
const Post = require('../models/post');


module.exports.createComments = async function(req,res){
    try {
        let post = await  Post.findById(req.body.post);
        let comment = await Comment.create({
            comment:req.body.postcomments,
            user:req.user._id,
            post:req.body.post
        });
            post.comment.push(comment);
            post.save();
            res.redirect('/');
    }catch(err) {
        console.log(`Error is ${err}`);
        return;
    }
}

module.exports.destroyComments = async function(req,res) {
    try{
        let comment = await Comment.findById(req.params.id);
        if(comment.user == req.user.id) {
            let postId = comment.post;
            comment.remove();
           await  Post.findByIdAndUpdate(postId,{$pull:{comment:req.params.id}}); 
                return res.redirect('back');
        }else{
            return res.redirect('back');
        }

    }catch(err){
        console.log(`Error is ${err}`);
        return;
    }
   
}
