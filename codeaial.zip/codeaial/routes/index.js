//create a same instance of same "express" when app index.js also called the "express"
const express = require('express');
//require the controller module from homeController
const homeController = require('../controller/home_controller');

const userSignupController = require('../controller/user-signup-controller');
//exports the router module
const router = express.Router();

// const passport = require('passport');
router.get('/',homeController.home);
router.use('/users',require('./user'));
router.use('/createUserSignup',require('./user-signup-signin'));
router.use('/sign-in/',require('./user-signup-signin'));
router.use('/signout',userSignupController.signout);
router.use('/posts',require('./post'));
router.use('/comments',require('./comments'))
module.exports = router;