const express = require('express');
const router = express.Router();
const passport = require('passport');
const postController = require('../controller/post-controller');

router.post('/create',passport.checkAuthetication,postController.create);
router.get('/destroy/:id',passport.checkAuthetication,postController.destroy);
module.exports = router;