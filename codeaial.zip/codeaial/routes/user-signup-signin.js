const express = require('express');

const router = express.Router();

const passport = require('passport');

const userSignupSigninController = require('../controller/user-signup-controller');
router.post('/',passport.checkAuthetication,userSignupSigninController.signup);
router.get('/',userSignupSigninController.signin);
//use passport as a middleware autheticator
router.post('/login',passport.authenticate('local',{failureRedirect:'/sign-in'}),userSignupSigninController.login);

module.exports = router;