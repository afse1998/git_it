const express = require('express');
const router = express.Router();
const passport = require('passport');
const commentsController = require('../controller/comment-controller');
router.post('/create',passport.checkAuthetication,commentsController.createComments);
router.get('/destroy/:id',passport.checkAuthetication,commentsController.destroyComments);
module.exports = router;