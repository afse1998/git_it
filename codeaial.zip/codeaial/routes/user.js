const express = require('express');
const router = express.Router();
const passport = require('passport');
const userController = require('../controller/user_controller');
router.post('/update/:id',passport.checkAuthetication,userController.update);
router.get('/profile/:id',passport.checkAuthetication,userController.profile);
module.exports = router;