//require passport
const passport = require('passport');

//require a local statergy using Statergy function
const LocalStatergy = require('passport-local').Strategy;
//getting the user from model
const User = require('../models/user');
//authetication suing passport
passport.use(new LocalStatergy({
    // This is the syntax used for which username we are providing for authetication 
    usernameField:'email'
    },function(email,password,done){ // "done" is a function used for if the authentication is establised a successful connection
        //find the user and establish an identity
        User.findOne({email:email},function(err,user){
            if(err){
                console.log(`Error in finding user in passport ${err}`);
                return done(err);
            }
            if(!user || user.password != password){
                return console.log(`Invalid user name / password`);
                return done(null,false);
            }
            return done(null,user);
        });
    }
));


//serializing the user to decide which key to be kept in cookies
passport.serializeUser(function(user,done){
    done(null,user.id);
});

//deserializing the user from cookies
passport.deserializeUser(function(id,done){
    User.findById(id,function(err,user){
        if(err){
            console.log(`Error in deserializing`);
            return done(err);
        }
        return done(null,user);// null is passed for no error is present
    });
});

//check user is autheticated or not and find the respected user data
passport.checkAuthetication = function(req,res,next){
    if(req.isAuthenticated()){
        return next();
    }
    return res.redirect('/sign-in');
};

passport.setAutheticatedUser = function(req,res,next){
    if(req.isAuthenticated()){
        res.locals.user = req.user;
    }
    next();
}

module.exports = passport;