// require mongoose
const mongoose = require('mongoose');
//creating a user schema
const userSchema = new mongoose.Schema({
    email:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true
    },
    name:{
        type:String,
        required:true
    }
},{
    timestamps:true // time stamp is used for knowing when the data is created and updated in database
});
//creating a model of userSchema
const User = mongoose.model('User',userSchema);
//exporting the module
module.exports = User;