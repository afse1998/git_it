const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
    content:{
        type:String,
        required:true,
    },
    user:{
        type:mongoose.Schema.Types.ObjectId, // refer each comment for a specific user as ObjectId is unique for each user
        ref:'User' // ref is used for to which Schema it will refer to for specific user here it is user schema
    },
    comment:[
        {
            type:mongoose.Schema.Types.ObjectId,
            ref:'Comment'
        }
    ]
},{
        timestamps:true 
});

const Post = mongoose.model('Post',postSchema);
module.exports = Post;